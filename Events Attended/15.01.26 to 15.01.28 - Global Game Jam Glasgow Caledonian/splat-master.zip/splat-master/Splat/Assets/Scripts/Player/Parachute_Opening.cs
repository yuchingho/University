﻿//using UnityEngine;
//using System.Collections;

//public class Parachute_Opening : MonoBehaviour {

//    void Start()
//    {
//        bool isOpen = TryOpenParachute();
//    }

//        bool TryOpenParachute() {
//        int random = Random.Range (0, 2);

//        if (random == 1)
//        { 
//            Debug.Log ("The parachute open");
//            return true;
//        }
//        else 
//        {
//            Debug.Log ("The parachute doesn't open");
//            return false;
//        }
//    }
//}